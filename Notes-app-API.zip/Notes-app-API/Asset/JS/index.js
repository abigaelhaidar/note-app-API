// src/index.js
import './Asset/CSS/style.css'; // Mengimpor style.css
import { createNote, fetchNotes, fetchNoteById, updateNote, deleteNote } from './app.js'; // Mengimpor fungsi dari app.js

const notesListElement = document.querySelector('#notesList');
const notesButton = document.querySelector('.notes-button');
const noteModal = document.getElementById('noteModal');
const closeModal = document.querySelector('.close');

// Fungsi untuk merender catatan ke dalam daftar
function renderNotes(notes) {
    notesListElement.innerHTML = notes.map(note => createNoteItemElement(note)).join('');
}

// Membuat elemen catatan
function createNoteItemElement({ id, title, body }) {
    return `
        <div class="note-item" data-noteid="${id}">
            <h3>${title}</h3>
            <p>${body}</p>
            <button class="edit-button" data-id="${id}">Edit</button>
            <button class="delete-button" data-id="${id}">Delete</button>
        </div>
    `;
}

// Event listener untuk membuka modal
notesButton.addEventListener('click', function() {
    noteModal.style.display = 'block';
});

// Event listener untuk menutup modal
closeModal.addEventListener('click', function() {
    noteModal.style.display = 'none';
});

// Tutup modal saat area di luar modal diklik
window.addEventListener('click', function(event) {
    if (event.target === noteModal) {
        noteModal.style.display = 'none';
    }
});

// Menggunakan event listener untuk mengelola penambahan catatan
document.querySelector('note-content').addEventListener('note-added', async (event) => {
    const newNote = { title: event.detail.title, body: event.detail.body };
    await createNote(newNote); // Memanggil fungsi untuk membuat catatan
    const notes = await fetchNotes(); // Ambil daftar catatan terbaru
    renderNotes(notes); // Render catatan yang diperbarui
});

// Menambahkan event listener untuk tombol Edit dan Delete
notesListElement.addEventListener('click', async (event) => {
    if (event.target.classList.contains('edit-button')) {
        const noteId = event.target.getAttribute('data-id');
        const noteToEdit = await fetchNoteById(noteId); // Ambil catatan yang akan diedit

        // Mengisi form modal dengan data catatan yang akan diedit
        const noteContentElement = document.querySelector('note-content');
        noteContentElement.shadowRoot.querySelector('#title').value = noteToEdit.title;
        noteContentElement.shadowRoot.querySelector('#body').value = noteToEdit.body;

        noteModal.style.display = 'block';

        // Menyimpan perubahan saat catatan diedit
        noteContentElement.addEventListener('note-added', async (event) => {
            const updatedNote = { title: event.detail.title, body: event.detail.body };
            await updateNote(noteId, updatedNote); // Memanggil fungsi untuk mengupdate catatan
            const notes = await fetchNotes(); // Ambil daftar catatan terbaru
            renderNotes(notes); // Render catatan yang diperbarui
            noteModal.style.display = 'none';
        }, { once: true });
    }

    if (event.target.classList.contains('delete-button')) {
        const noteId = event.target.getAttribute('data-id');
        await deleteNote(noteId); // Memanggil fungsi untuk menghapus catatan
        const notes = await fetchNotes(); // Ambil daftar catatan terbaru
        renderNotes(notes); // Render catatan yang diperbarui
    }
});

// Menampilkan catatan saat aplikasi dimuat
(async () => {
    const notes = await fetchNotes(); // Mengambil catatan dari API
    renderNotes(notes); // Render catatan yang diambil
})();
