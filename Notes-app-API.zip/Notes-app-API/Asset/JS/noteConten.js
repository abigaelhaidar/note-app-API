class NoteContent extends HTMLElement {
  constructor() {
    super();
    const shadow = this.attachShadow({ mode: 'open' });
    this.notes = []; // Array untuk menyimpan catatan

    // Membuat elemen untuk title dan body
    const content = document.createElement('div');
    content.setAttribute('class', 'note');

    // HTML untuk input title dan body
    content.innerHTML = `
      <form id="noteForm">
        <div>
          <label for="title">Judul:</label>
          <input type="text" id="title" placeholder="${this.getAttribute('title-placeholder') || 'Masukkan judul...'}" required />
          <span id="titleError" class="error-message"></span>
        </div>
        <div>
          <label for="body">Catatan:</label>
          <textarea id="body" placeholder="${this.getAttribute('body-placeholder') || 'Tulis catatan Anda di sini...'}" required></textarea>
          <span id="bodyError" class="error-message"></span>
        </div>
        <button type="submit">Simpan Catatan</button>
      </form>
      <div id="notesContainer"></div> <!-- Tempat untuk menampilkan catatan -->
    `;

    // Menambahkan event listener untuk validasi
    const form = content.querySelector('#noteForm');
    form.addEventListener('submit', this.handleSubmit.bind(this));

    // Menambahkan event listener untuk validasi real-time
    const titleInput = content.querySelector('#title');
    const bodyInput = content.querySelector('#body');

    titleInput.addEventListener('input', this.validateTitle.bind(this));
    bodyInput.addEventListener('input', this.validateBody.bind(this));

    shadow.appendChild(content);
    this.styleElement();
  }

  validateTitle(event) {
    const title = event.target.value.trim();
    const errorMessage = this.shadowRoot.querySelector('#titleError');
    const titleInput = this.shadowRoot.querySelector('#title');

    // Reset pesan error dan gaya bingkai
    errorMessage.textContent = '';
    titleInput.classList.remove('invalid');

    // Validasi untuk title
    if (title.length < 5) {
      errorMessage.textContent = 'Judul harus terdiri dari minimal 5 karakter!';
      titleInput.classList.add('invalid'); // Tambahkan kelas invalid
    }
  }

  validateBody(event) {
    const body = event.target.value.trim();
    const errorMessage = this.shadowRoot.querySelector('#bodyError');
    const bodyInput = this.shadowRoot.querySelector('#body');

    // Reset pesan error dan gaya bingkai
    errorMessage.textContent = '';
    bodyInput.classList.remove('invalid');

    // Validasi untuk body
    if (body.length < 10) {
      errorMessage.textContent = 'Catatan harus terdiri dari minimal 10 karakter!';
      bodyInput.classList.add('invalid');
    }
  }

  handleSubmit(event) {
    event.preventDefault();
    const title = this.shadowRoot.querySelector('#title').value.trim();
    const body = this.shadowRoot.querySelector('#body').value.trim();
    let isValid = true;

    // Reset pesan error dan gaya bingkai
    this.shadowRoot.querySelector('#titleError').textContent = '';
    this.shadowRoot.querySelector('#bodyError').textContent = '';
    this.shadowRoot.querySelector('#title').classList.remove('invalid');
    this.shadowRoot.querySelector('#body').classList.remove('invalid');

    // Validasi untuk title
    if (title.length < 5) {
      this.shadowRoot.querySelector('#titleError').textContent = 'Judul harus terdiri dari minimal 5 karakter!';
      this.shadowRoot.querySelector('#title').classList.add('invalid');
      isValid = false;
    }

    // Validasi untuk body
    if (body.length < 10) {
      this.shadowRoot.querySelector('#bodyError').textContent = 'Catatan harus terdiri dari minimal 10 karakter!';
      this.shadowRoot.querySelector('#body').classList.add('invalid');
      isValid = false;
    }

    if (isValid) {
      const newNote = { title, body };
      this.dispatchEvent(new CustomEvent('note-added', { detail: newNote, bubbles: true }));

      this.resetForm();
    }
  }

  addNote(title, body) {
    this.notes.push({ title, body }); // Menyimpan catatan dalam array
    this.displayNotes(); // Memperbarui tampilan catatan
  }

  displayNotes() {
    const notesContainer = this.shadowRoot.querySelector('#notesContainer');
    notesContainer.innerHTML = '';
  }

  resetForm() {
    this.shadowRoot.querySelector('#title').value = '';
    this.shadowRoot.querySelector('#body').value = '';
    this.shadowRoot.querySelector('#titleError').textContent = '';
    this.shadowRoot.querySelector('#bodyError').textContent = '';
    this.shadowRoot.querySelector('#title').classList.remove('invalid');
    this.shadowRoot.querySelector('#body').classList.remove('invalid');
  }

  styleElement() {
    const style = document.createElement('style');
    style.textContent = `
      .note {
        padding: 20px;
        border-radius: 5px;
        margin: 10px 0;
        max-width: 600px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
      }
      .error-message {
        color: red;
        font-size: 0.9rem;
      }
      input[type="text"], textarea {
        width: 100%;
        padding: 10px;
        margin: 5px 0;
        border: 1px solid #ccc;
        border-radius: 4px;
        transition: border-color 0.3s;
      }
      textarea {
        height: 100px; /* Ubah tinggi sesuai kebutuhan */
      }
      input.invalid, textarea.invalid {
        border-color: red; /* Mengubah warna bingkai menjadi merah */
      }
      button {
        padding: 10px;
        background-color: #A66E38;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
      }
      button:hover {
        background-color: #9B5B2E;
      }
      .note-item {
        margin: 10px 0;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 5px;
      }
    `;
    this.shadowRoot.appendChild(style);
  }
}

customElements.define('note-content', NoteContent);
