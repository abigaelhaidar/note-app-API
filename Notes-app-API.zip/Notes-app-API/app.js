// src/app.js
import './Asset/CSS/style.css';
import './Asset/JS/footer-bar.js';  // Import custom element
import './Asset/JS/noteConten.js'; 

const API_URL = 'https://notes-api.dicoding.dev/v2';
const notesListElement = document.querySelector('#notesList');
const noteModal = document.getElementById('noteModal');
const loadingIndicator = document.createElement('div');
loadingIndicator.className = 'loading';
loadingIndicator.textContent = 'Loading...';

async function fetchNotes() {
    try {
        showLoading();
        const response = await fetch(`${API_URL}/notes`);
        const data = await response.json();
        return data.notes;
    } catch (error) {
        console.error('Error fetching notes:', error);
    } finally {
        hideLoading();
    }
}

async function createNote(note) {
    try {
        showLoading();
        const response = await fetch(`${API_URL}/notes`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(note),
        });
        return await response.json();
    } catch (error) {
        console.error('Error creating note:', error);
    } finally {
        hideLoading();
    }
}

async function deleteNote(noteId) {
    try {
        showLoading();
        await fetch(`${API_URL}/notes/${noteId}`, {
            method: 'DELETE',
        });
    } catch (error) {
        console.error('Error deleting note:', error);
    } finally {
        hideLoading();
    }
}

function showLoading() {
    document.body.appendChild(loadingIndicator);
}

function hideLoading() {
    if (loadingIndicator.parentElement) {
        loadingIndicator.parentElement.removeChild(loadingIndicator);
    }
}

function renderNotes(notes) {
    const listOfNoteItem = notes.map(note => `
        <div class="note-item" data-noteid="${note.id}">
            <h3>${note.title}</h3>
            <p>${note.body}</p>
            <button class="edit-button" data-id="${note.id}">Edit</button>
            <button class="delete-button" data-id="${note.id}">Delete</button>
        </div>
    `).join('');
    
    notesListElement.innerHTML = listOfNoteItem;
}

// Fetch and display notes on page load
window.addEventListener('DOMContentLoaded', async () => {
    const notes = await fetchNotes();
    renderNotes(notes);
});
