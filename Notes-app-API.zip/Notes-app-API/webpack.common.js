const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');

module.exports = {
  entry: path.join(__dirname, 'app.js'), // Entry point untuk app.js
  output: {
    path: path.join(__dirname, 'dist'), // Output ke folder dist
    filename: 'bundle.js', // Nama file bundle
  },
  module: {
    rules: [
      {
        test: /\.css$/, // Menangani file CSS
        use: ['style-loader', 'css-loader'],
      },
      {
        test: /\.js$/, // Menangani file JavaScript
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env'],
          },
        },
      },
    ],
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: path.join(__dirname, 'index.html'), // Template HTML
      filename: 'index.html',
    }),
  ],
};
